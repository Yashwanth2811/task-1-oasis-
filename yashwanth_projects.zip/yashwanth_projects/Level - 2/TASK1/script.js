let currentInput = "0";
let operator = null;
let previousInput = null;

function appendNumber(number) {
    if (currentInput === "0") {
        currentInput = number;
    } else {
        currentInput += number;
    }
    updateDisplay();
}

function setOperation(op) {
    if (operator !== null) {
        calculate();
    }
    operator = op;
    previousInput = currentInput;
    currentInput = "";
}

function calculate() {
    if (operator === null || previousInput === null) return;

    const prev = parseFloat(previousInput);
    const curr = parseFloat(currentInput);

    let result;
    switch (operator) {
        case "+":
            result = prev + curr;
            break;
        case "-":
            result = prev - curr;
            break;
        case "*":
            result = prev * curr;
            break;
        case "/":
            result = curr !== 0 ? prev / curr : "Error";
            break;
    }

    currentInput = result.toString();
    operator = null;
    previousInput = null;
    updateDisplay();
}

function clearDisplay() {
    currentInput = "0";
    operator = null;
    previousInput = null;
    updateDisplay();
}

function updateDisplay() {
    document.getElementById("display").innerText = currentInput;
}
