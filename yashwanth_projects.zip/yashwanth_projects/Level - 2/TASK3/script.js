let tasks = [];
let completedTasks = [];

function addTask() {
    const taskInput = document.getElementById("taskInput");
    const taskText = taskInput.value.trim();

    if (taskText) {
        const task = {
            id: Date.now(),
            text: taskText,
            isCompleted: false
        };
        tasks.push(task);
        taskInput.value = "";
        renderTasks();
    }
}

function renderTasks() {
    const taskList = document.getElementById("taskList");
    const completedTaskList = document.getElementById("completedTaskList");

    taskList.innerHTML = "";
    completedTaskList.innerHTML = "";

    tasks.forEach(task => {
        const listItem = document.createElement("li");
        listItem.classList.add("task-item");
        listItem.innerHTML = `
            <span>${task.text}</span>
            <div class="task-actions">
                <button onclick="editTask(${task.id})">✏️</button>
                <button onclick="deleteTask(${task.id})">🗑️</button>
                <button onclick="completeTask(${task.id})">✅</button>
            </div>
        `;

        if (task.isCompleted) {
            completedTaskList.appendChild(listItem);
        } else {
            taskList.appendChild(listItem);
        }
    });
}

function editTask(taskId) {
    const newText = prompt("Edit your task:");
    if (newText) {
        tasks = tasks.map(task =>
            task.id === taskId ? { ...task, text: newText } : task
        );
        renderTasks();
    }
}

function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    renderTasks();
}

function completeTask(taskId) {
    tasks = tasks.map(task =>
        task.id === taskId ? { ...task, isCompleted: true } : task
    );
    renderTasks();
}

renderTasks();
